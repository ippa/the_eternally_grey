class Menu < Chingu::GameState
  def initialize
    
  end
end
