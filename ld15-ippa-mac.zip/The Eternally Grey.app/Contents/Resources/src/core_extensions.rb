#
# Monkeypatch stuff into Chingu.
#
module Chingu
  class Animation
    attr_accessor :delay
  end
end