#
# Core extensions
#
# Extensions to the classes GOSU offers
#
module Gosu
  class Color
    def average(other, weight)
    end
  end
end